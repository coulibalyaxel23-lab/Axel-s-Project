package com.example.Proposition.d.adhesion.BnB.mapper;

import com.example.Proposition.d.adhesion.BnB.dto.BulletinAdhesionDto;

import java.util.HashMap;
import java.util.Map;

/**
 * Mappe les données vers les paramètres du rapport Jasper.
 * Les champs sont entièrement dynamiques : tout ce qui est dans le JSON
 * est envoyé au rapport (clé = paramètre, type déduit de la valeur).
 */
public final class BulletinAdhesionMapper {

    private BulletinAdhesionMapper() {
    }

    /**
     * Convertit le JSON (Map) en paramètres Jasper de façon dynamique.
     * - Chaque clé du JSON = un paramètre du rapport.
     * - Type déduit de la valeur : Boolean → Boolean, sinon → String.
     * Aucune liste de champs figée : seuls les champs présents dans le JSON sont utilisés.
     */
    public static Map<String, Object> toReportParametersFromMap(Map<String, Object> data) {
        Map<String, Object> params = new HashMap<>();
        if (data == null || data.isEmpty()) {
            return params;
        }
        for (Map.Entry<String, Object> e : data.entrySet()) {
            String key = e.getKey();
            Object value = e.getValue();
            if (value instanceof Boolean) {
                params.put(key, value);
            } else if (isBooleanValue(value)) {
                params.put(key, toBoolean(value));
            } else {
                params.put(key, toString(value));
            }
        }
        return params;
    }

    private static boolean isBooleanValue(Object v) {
        if (v == null) return false;
        String s = String.valueOf(v).trim().toLowerCase();
        return "true".equals(s) || "false".equals(s) || "1".equals(s) || "0".equals(s)
                || "oui".equals(s) || "non".equals(s) || "yes".equals(s) || "no".equals(s);
    }

    /**
     * Mappe le DTO bulletin d'adhésion vers les paramètres du rapport (compatibilité).
     */
    public static Map<String, Object> toReportParameters(BulletinAdhesionDto dto) {
        Map<String, Object> params = new HashMap<>();
        if (dto == null) {
            return params;
        }
        put(params, "nom", dto.getNom());
        put(params, "dateNaissance", dto.getDateNaissance());
        put(params, "adresseDomicile", dto.getAdresseDomicile());
        put(params, "telephone", dto.getTelephone());
        put(params, "email", dto.getEmail());
        put(params, "nationalite", dto.getNationalite());
        put(params, "typePieceIdentite", dto.getTypePieceIdentite());
        put(params, "numeroPieceIdentite", dto.getNumeroPieceIdentite());
        put(params, "profession", dto.getProfession());
        put(params, "capitalAssure", dto.getCapitalAssure());
        put(params, "dureeContrat", dto.getDureeContrat());
        put(params, "nombreCotisantsMinimum", dto.getNombreCotisantsMinimum());
        put(params, "dateEffet", dto.getDateEffet());
        put(params, "primePayer", dto.getPrimePayer());
        put(params, "frequencePaiement", dto.getFrequencePaiement());
        put(params, "modePaiement", dto.getModePaiement());
        put(params, "optionVersement", dto.getOptionVersement());
        put(params, "numeroTelephoneMobile", dto.getNumeroTelephoneMobile());
        put(params, "operateurMobile", dto.getOperateurMobile());
        put(params, "numeroBanque", dto.getNumeroBanque());
        put(params, "nomBanque", dto.getNomBanque());
        put(params, "adresseBanque", dto.getAdresseBanque());
        params.put("jeConsens1", Boolean.TRUE.equals(dto.getJeConsens1()));
        params.put("jeConsens2", Boolean.TRUE.equals(dto.getJeConsens2()));
        put(params, "signature", dto.getSignature());
        put(params, "date", dto.getDate());
        return params;
    }

    private static void put(Map<String, Object> params, String key, String value) {
        params.put(key, value != null ? value : "");
    }

    private static String toString(Object v) {
        if (v == null) return "";
        if (v instanceof String) return (String) v;
        if (v instanceof Map || v instanceof Iterable) return String.valueOf(v);
        return String.valueOf(v);
    }

    private static Boolean toBoolean(Object v) {
        if (v instanceof Boolean) return (Boolean) v;
        if (v == null) return false;
        String s = String.valueOf(v).trim().toLowerCase();
        return "true".equals(s) || "1".equals(s) || "oui".equals(s) || "yes".equals(s);
    }
}
